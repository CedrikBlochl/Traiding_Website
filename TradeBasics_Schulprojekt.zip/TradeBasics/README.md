# TradeBasics – Einfaches Trading-Schulprojekt

**Idee:** Eine responsive Informationswebsite über Trading und Kryptowährungen. Sie erklärt Grundbegriffe und zeigt echte Kurse von Bitcoin, Ethereum und Solana an. **Kein echter Handel, kein Konto, kein Geld.**

## Anforderungen der Schule

| Anforderung | Umsetzung |
|---|---|
| Responsiv mit Bootstrap oder Tailwind | Bootstrap 5 (Navigation, Grid, Buttons, Karten) |
| REST-API | CoinPaprika: `https://api.coinpaprika.com/v1/tickers/btc-bitcoin` (sowie ETH und SOL) |
| Selbst erstellt / ohne CMS | Eigenes HTML, CSS und JavaScript |
| Unterseiten | Startseite, Kurse, Kontakt, Impressum, Datenschutz |
| Online abrufbar | GitHub Pages, nachdem ihr die Dateien hochgeladen und Pages aktiviert habt |
| Versionsverwaltung | GitHub Repository und Commits |
| Genehmigung | Die Idee vor dem Start der Lehrkraft vorlegen |

## Aufbau

- `index.html` – Startseite, erklärt Trading
- `kurse.html` – Kurse werden per REST-API geladen
- `kontakt.html` – Kontaktformular öffnet das E-Mail-Programm
- `impressum.html` – Platzhalter für rechtliche Pflichtangaben
- `datenschutz.html` – Mustertext, muss geprüft/angepasst werden
- `assets/style.css` – eigenes Design
- `assets/script.js` – REST-API-Abfrage mit `fetch()`, Ausgabe, Kontaktfunktion

## Lokal starten

Öffnet `index.html` im Browser. Für das Testen der REST-API empfiehlt sich ein lokaler Webserver, z. B. in VS Code mit **Live Server**. Alternativ im Projektordner:

```bash
python3 -m http.server 5500
```

Dann `http://localhost:5500` im Browser öffnen. Für Bootstrap und die Kurse benötigt ihr Internet.

## Auf GitHub hochladen und online veröffentlichen

1. Auf github.com anmelden und ein neues Repository `tradebasics` erstellen.
2. **Add file → Upload files** und alle fünf HTML-Dateien sowie den Ordner `assets` (mit den Dateien) hochladen; **Commit changes**.
3. Repository öffnen → **Settings → Pages**.
4. Unter **Build and deployment**: **Deploy from a branch** auswählen, dann **main** und **/(root)**, **Save**.
5. Nach dem Deploy ist die Seite üblicherweise unter `https://BENUTZERNAME.github.io/tradebasics/` erreichbar. Die tatsächliche URL zeigt GitHub Pages an.
6. Bei Änderungen neue Dateien hochladen und einen Commit mit einer aussagekräftigen Nachricht erstellen.

**WICHTIG vor öffentlicher Veröffentlichung:** Platzhalter-E-Mail `kontakt@beispiel.at` in `kontakt.html`, `impressum.html` und `assets/script.js` ersetzen. Impressum und Datenschutzerklärung an echte Personen, Hosting und rechtliche Anforderungen anpassen. Mit Lehrkraft abstimmen.

## Wie funktioniert die API?

1. Ein Browser öffnet `kurse.html`.
2. Die Datei `assets/script.js` ruft über `fetch()` eine URL bei CoinPaprika auf.
3. Der Server liefert Daten im **JSON-Format** zurück.
4. JavaScript liest z. B. `coin.quotes.USD.price` aus und zeigt Preis und 24-Stunden-Änderung an.
5. Über **„Kurse neu laden“** kann die Anfrage noch einmal gestartet werden.

Wenn die API nicht erreichbar ist, erscheint eine Fehlermeldung statt erfundener Kurse. Daten können zeitverzögert sein.

## Kurze Präsentation (ca. 2–3 Minuten)

**1. Idee:** „Wir wollten eine einfache Trading-Lernseite machen. Man kann Grundlagen lernen und echte Kryptokurse ansehen.“

**2. Technik:** „Wir haben HTML für die Seiten, CSS fürs Design und Bootstrap für die mobile Ansicht verwendet. JavaScript lädt über `fetch()` die Daten einer REST-API.“

**3. Demo:** Startseite öffnen → auf „Kurse“ klicken → Bitcoin, Ethereum, Solana zeigen → „Kurse neu laden“ drücken → auf dem Handy die Navigation testen.

**4. GitHub:** Repository zeigen und erklären, dass Commits Änderungen speichern und GitHub Pages die Website online bereitstellt.

**5. Datenschutz:** „Wir haben kein Login und keine Datenbank. Das Kontaktformular öffnet nur das E-Mail-Programm.“

## Für zwei Schüler (optional)

- Schüler A: Startseite, Kontakt, Impressum, Datenschutz, Design.
- Schüler B: Kursseite, JavaScript, REST-API, GitHub Pages.
- Beide: testen, Commits erstellen, gemeinsam erklären.

## API und Framework

- Bootstrap: https://getbootstrap.com/docs/5.3/
- CoinPaprika API: https://coinpaprika.com/developers

**Hinweis:** Das Projekt ist eine Lernseite, keine Trading-Plattform. Die Datenquelle ist öffentlich und kann Rate-Limits/zeitliche Verzögerungen haben.
