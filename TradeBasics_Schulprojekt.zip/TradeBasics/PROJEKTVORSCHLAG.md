# Projektvorschlag zur Genehmigung – TradeBasics

**Projekttitel:** TradeBasics – Trading einfach erklärt

**Team:** [Name Schüler 1] / [Name Schüler 2] (maximal zwei Schüler)

**Projektidee:** Wir erstellen eine einfache, responsive Website über Trading und Kryptowährungen. Auf der Startseite erklären wir Grundbegriffe wie Trading, Kurs und Risiko. Auf der Kursseite zeigen wir aktuelle Preise von Bitcoin, Ethereum und Solana an. Dafür laden wir über JavaScript und eine öffentliche REST-API Daten von CoinPaprika. Die Website dient ausschließlich der Information; es werden keine echten Trades durchgeführt.

**Technik:** HTML, CSS, JavaScript, Bootstrap 5, CoinPaprika-REST-API.

**Seiten:** Startseite, Kursübersicht, Kontakt, Impressum, Datenschutzerklärung.

**Projektverwaltung und Hosting:** GitHub (Versionsverwaltung) und GitHub Pages (Veröffentlichung).

**Umfang:** bewusst einfach gehalten, ohne Datenbank, Benutzerkonto oder CMS. Alle wesentlichen Teile können wir im Unterricht selbst erklären.

**Bitte um Genehmigung der Aufgabenstellung.**
