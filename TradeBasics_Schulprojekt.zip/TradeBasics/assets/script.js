// TradeBasics: Holt drei Kryptokurse über eine öffentliche REST-API.
// Die API liefert JSON. Es wird kein eigenes Backend benötigt.

const coins = [
  { id: "btc-bitcoin", zeichen: "₿" },
  { id: "eth-ethereum", zeichen: "Ξ" },
  { id: "sol-solana", zeichen: "◎" }
];

const liste = document.getElementById("coin-list");
const neuLadenButton = document.getElementById("reload-button");

// Diese Funktion macht aus einer Zahl einen formatierten Dollar-Betrag.
function preisFormatieren(preis) {
  return new Intl.NumberFormat("de-AT", {
    style: "currency", currency: "USD", maximumFractionDigits: 2
  }).format(preis);
}

// fetch() lädt Daten von einer REST-API. await wartet auf die Antwort.
async function ladeKurse() {
  liste.innerHTML = '<p class="text-muted-custom">Kurse werden geladen …</p>';
  neuLadenButton.disabled = true;

  try {
    const daten = await Promise.all(coins.map(async (coin) => {
      const antwort = await fetch("https://api.coinpaprika.com/v1/tickers/" + coin.id);
      if (!antwort.ok) throw new Error("HTTP " + antwort.status);
      return await antwort.json(); // JSON wird zu einem JavaScript-Objekt.
    }));

    // Die erhaltenen Daten werden als Bootstrap-Karten angezeigt.
    liste.innerHTML = daten.map((coin, index) => {
      const usd = coin.quotes.USD;
      const aenderung = usd.percent_change_24h;
      const klasse = aenderung >= 0 ? "positive" : "negative";
      const vorzeichen = aenderung > 0 ? "+" : "";

      return `
        <div class="col-md-6 col-lg-4">
          <article class="coin-card">
            <div class="d-flex align-items-center gap-3 mb-4">
              <div class="coin-symbol">${coins[index].zeichen}</div>
              <div><h2 class="h5 mb-0">${coin.name}</h2><span class="small-note">${coin.symbol}</span></div>
            </div>
            <p class="small-note mb-1">Aktueller Preis</p>
            <p class="coin-price mb-2">${preisFormatieren(usd.price)}</p>
            <p class="mb-0">Änderung in 24 h: <span class="${klasse}">${vorzeichen}${aenderung.toFixed(2)} %</span></p>
          </article>
        </div>`;
    }).join("");

    document.getElementById("last-updated").textContent =
      "Zuletzt abgefragt: " + new Date().toLocaleString("de-AT");
  } catch (fehler) {
    console.error("Kurse konnten nicht geladen werden:", fehler);
    liste.innerHTML = '<div class="col-12"><div class="alert alert-warning">Die Kursdaten sind gerade nicht verfügbar. Bitte später erneut versuchen.</div></div>';
    document.getElementById("last-updated").textContent = "";
  } finally {
    neuLadenButton.disabled = false;
  }
}

// Der Code wird nur auf der Kurs-Seite ausgeführt.
if (liste && neuLadenButton) {
  neuLadenButton.addEventListener("click", ladeKurse);
  ladeKurse();
}

// Kontakt: Öffnet das E-Mail-Programm; die Website speichert nichts.
const kontaktFormular = document.getElementById("contact-form");
if (kontaktFormular) {
  kontaktFormular.addEventListener("submit", function (event) {
    event.preventDefault();
    const name = document.getElementById("contact-name").value.trim();
    const nachricht = document.getElementById("contact-message").value.trim();
    const betreff = encodeURIComponent("Anfrage von " + name + " – TradeBasics");
    const inhalt = encodeURIComponent(nachricht + "\n\nVon: " + name);
    window.location.href = "mailto:kontakt@beispiel.at?subject=" + betreff + "&body=" + inhalt;
  });
}
